# EX

 1. Create a Database:

 2. Create a Collection:

 3. Insert a Document:

 4. Find a Document:

 5. Update a Document:

 6. Delete a Document:

 7. Inserting multiple documents at once:

 8. Finding documents with a greater than or equal to operator:

 9. Updating multiple documents at once:

 10. Deleting multiple documents at once:

 11. Using the aggregation framework to group documents by a field:

 12. Finding documents with a nested field:

 13. Updating a nested field:

 14. Deleting a collection:

 15. Using the aggregation framework to sort and limit results:

 16. Using the aggregation framework to calculate an average:
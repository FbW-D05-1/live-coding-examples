# EX

 1. Erstellen Sie eine Datenbank:

 2. Erstellen Sie eine Sammlung:

 3. Ein Dokument einfügen:

 4. Ein Dokument suchen:

 5. Ein Dokument aktualisieren:

 6. Ein Dokument löschen:

 7. Einfügen mehrerer Dokumente auf einmal:

 8. Suchen von Dokumenten mit dem Operator "größer als" oder "gleich":

 9. Gleichzeitiges Aktualisieren mehrerer Dokumente:

 10. Gleichzeitiges Löschen mehrerer Dokumente:

 11. Verwendung des Aggregationsrahmens zur Gruppierung von Dokumenten nach einem Feld:

 12. Suchen von Dokumenten mit einem verschachtelten Feld:

 13. Ein verschachteltes Feld aktualisieren:

 14. Löschung einer Sammlung:

 15. Verwendung des Aggregationsrahmens zum Sortieren und Begrenzen der Ergebnisse:

 16. Verwendung des Aggregationsrahmens zur Berechnung eines Durchschnitts: